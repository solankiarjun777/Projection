package processing.app.exec;

public interface LineProcessor {
  void processLine(final String line);
}
