package processing.app.contrib;


public class IgnorableException extends Exception {
  public IgnorableException(String msg) {
    super(msg);
  }
}
