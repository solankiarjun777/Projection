A very simple SVG exporter based on the PDF Export library that ships with Processing. Uses Batik's [SVG Generator](http://xmlgraphics.apache.org/batik/using/svg-generator.html).
